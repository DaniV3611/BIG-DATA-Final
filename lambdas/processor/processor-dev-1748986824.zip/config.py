import re

HTML_EXTENSION = re.compile(r".*\.html$", re.IGNORECASE)

CSV_BUCKET_NAME = "final-gizmo"
